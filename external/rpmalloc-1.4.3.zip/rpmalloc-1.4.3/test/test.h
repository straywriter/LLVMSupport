
#pragma once

extern int
test_run(int argc, char** argv);
